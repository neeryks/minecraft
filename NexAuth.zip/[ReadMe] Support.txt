================== Links ==================
Discord Server: http://discord.gg/QBcFdefyeW
Source Code, Bug Tracker & Suggestions: https://github.com/nulli0n/
More Resources: https://spigotmc.org/resources/authors/nightexpress.81588/
Donations: https://www.paypal.me/nightexpress
Plugins Wiki: http://nexwiki.info/
===========================================


DO NOT USE RATING (1-5 STARS) TO ASK QUESTIONS OR REPORT BUGS!